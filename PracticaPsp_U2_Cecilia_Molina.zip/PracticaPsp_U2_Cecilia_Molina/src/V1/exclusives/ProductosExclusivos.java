package V1.exclusives;


import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class ProductosExclusivos {

    private final Map<String, String> productos = new HashMap<>();
    private final Random random = new Random();

    public ProductosExclusivos() {
        // Inicializo *A–F* como libres
        productos.put("A", "LIBRE");
        productos.put("B", "LIBRE");
        productos.put("C", "LIBRE");
        productos.put("D", "LIBRE");
        productos.put("E", "LIBRE");
        productos.put("F", "LIBRE");
    }


    //  1. ASEGURAR PRIMER PRODUCTO

    public synchronized void asegurarPrimer(String cliente, String producto)
            throws InterruptedException {

        System.out.println(cliente + " intenta asegurar producto " + producto);

        while (!productos.get(producto).equals("LIBRE")) {
            System.out.println(cliente + " espera " + producto + " está ocupado");
            wait();
        }

        // retardo 2–5 segundos
        Thread.sleep(2000 + random.nextInt(3000));

        productos.put(producto, "ASEGURADO_POR_" + cliente);
        System.out.println(cliente + " asegura " + producto);
    }


    //  2. ASEGURAR SEGUNDO PRODUCTO

    public synchronized boolean asegurarSegundoConTimeout(
            String cliente, String producto)
            throws InterruptedException {

        System.out.println(cliente + " intenta asegurar segundo producto " + producto);

        long inicio = System.currentTimeMillis();
        long timeout = 4000; // 4 segundos

        while (!productos.get(producto).equals("LIBRE")) {

            long tiempoRestante = timeout - (System.currentTimeMillis() - inicio);

            if (tiempoRestante <= 0) {
                System.out.println(cliente + " se cansó de esperar: fallo en segundo producto");
                return false;
            }

            wait(tiempoRestante);
        }

        // retardo aleatorio
        Thread.sleep(2000 + random.nextInt(3000));

        productos.put(producto, "ASEGURADO_POR_" + cliente);
        System.out.println(cliente + " asegura " + producto + " como segundo");
        return true;
    }


    //  3. CONFIRMAR COMPRA

    public synchronized void confirmarCompra(String cliente, String p1, String p2) {

        productos.put(p1, "VENDIDO");
        productos.put(p2, "VENDIDO");

        System.out.println( cliente + " confirma paquete [" + p1 + ", " + p2 + "]");
        notifyAll();
    }


    //  4. LIBERAR PRODUCTO

    public synchronized void liberar(String producto) {
        productos.put(producto, "LIBRE");
        System.out.println(" Producto " + producto + " ha sido liberado");
        notifyAll();
    }
}
