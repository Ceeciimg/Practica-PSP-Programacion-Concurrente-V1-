package V1.storage;

import V1.model.Pedido;

import java.util.LinkedList;
import java.util.Queue;

public class ColaPedidos {

    private final int LIMITE = 25;  // capacidad máxima
    private Queue<Pedido> cola = new LinkedList<>();

    public ColaPedidos() {
        this.cola = new LinkedList<>();
    }

    // AÑADIR PEDIDO (metodo para producir)

    public synchronized void añadir(Pedido pedido) throws InterruptedException {


        while (cola.size() == LIMITE) { // sila cola esta llena, hay que esperar
            System.out.println("Cola llena el cliente espera...");
            wait();
        }

        // Añadir pedido
        cola.add(pedido);
        System.out.println(" Pedido añadido " + pedido);

        // avisa al condumidor de que hay un nuevo eelemnto
        notifyAll();
    }


    // RETIRAR PEDIDO (método para consumir)

    public synchronized Pedido retirar() throws InterruptedException {

        // Si la cola está vacía, toca esperar
        while (cola.isEmpty()) {
            System.out.println("Cola vacía: Gestor/Transportista espera...");
            wait();
        }

        Pedido pedido = cola.poll();
        System.out.println("Pedido retirado: " + pedido);

        // Notificar al productor que hay espacio libre
        notifyAll();

        return pedido;
    }

    // para saber cuantos pedidos hay
    public synchronized int tamaño() {
        return cola.size();
    }
}

