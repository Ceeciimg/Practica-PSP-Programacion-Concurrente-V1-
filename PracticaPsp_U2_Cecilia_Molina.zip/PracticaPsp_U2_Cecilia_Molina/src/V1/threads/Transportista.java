package V1.threads;

import V1.model.Pedido;
import V1.storage.ColaPedidos;

public class Transportista {

    private ColaPedidos cola;

    public Transportista(ColaPedidos cola) {
        this.cola = cola;
    }

    public Thread crearHilo() {

        return new Thread(() -> {
            while (true) {
                try {
                    // Retirar pedido de la cola
                    Pedido p = cola.retirar();

                    // Cambiar estado
                    p.setEstado(Pedido.Estado.ENVIADO);
                    System.out.println("Transportista envía " + p);

                    // SimulaR envío
                    Thread.sleep(1500);

                } catch (Exception e) {
                    System.out.println("Error en Transportista: " + e.getMessage());
                }
            }
        });
    }
}