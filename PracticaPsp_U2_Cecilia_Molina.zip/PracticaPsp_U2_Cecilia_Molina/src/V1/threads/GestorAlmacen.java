package V1.threads;
import V1.model.Pedido;
import V1.storage.ColaPedidos;
import java.util.Random;

public class GestorAlmacen implements Runnable{

    private final ColaPedidos cola;
    private String nombre;
    private final Random random = new Random();

    public GestorAlmacen(ColaPedidos cola, String nombre) {
        this.cola = cola;
        this.nombre = nombre;
    }


    @Override
    public void run() {

        while (true) {
            try {
                Pedido pedido = cola.retirar();
                pedido.setEstado(Pedido.Estado.PROCESANDO);

                System.out.println("Gestor procesa pedido: " + pedido);

                Thread.sleep(2000 + random.nextInt(3000));

                pedido.setEstado(Pedido.Estado.ENVIADO);

            } catch (Exception e) {
                System.out.println("Error en Gestor: " + e.getMessage());
            }
        }

    }
}
