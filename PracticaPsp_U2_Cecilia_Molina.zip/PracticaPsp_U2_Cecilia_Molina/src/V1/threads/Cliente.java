package V1.threads;
import V1.exclusives.ProductosExclusivos;
import V1.model.Pedido;
import V1.storage.ColaPedidos;
import java.util.Random;

public class Cliente extends Thread {

    private final ColaPedidos cola;
    private final ProductosExclusivos exclusivos;
    private final Random random = new Random();
    private int contadorPedidos = 1;

    public Cliente(String nombre, ColaPedidos cola, ProductosExclusivos exclusivos) {
        super(nombre);
        this.cola = cola;
        this.exclusivos = exclusivos;
    }

    @Override
    public void run() {

        while (true) {
            try {
                // 1. generar pedido normal
                Pedido pedido = new Pedido(getName() + "_P" + contadorPedidos, "ProductoRandom",
                        Pedido.Estado.PENDIENTE
                );

                cola.añadir(pedido);
                System.out.println(getName() + "produce pedido " + pedido);
                contadorPedidos++;

                Thread.sleep(900);

                // 2. compra de productos exclusivos
                intentarComprarPack();

            } catch (Exception e) {
                System.out.println("Error en " + getName() + ": " + e.getMessage());
            }
        }
    }

    private void intentarComprarPack() throws InterruptedException {

        // productos posibles
        String[] productos = {"A", "B", "C", "D", "E", "F"};

        // se eligen dos productos posibles
        String p1 = productos[random.nextInt(productos.length)];
        String p2 = productos[random.nextInt(productos.length)];
        while (p1.equals(p2)) {
            p2 = productos[random.nextInt(productos.length)];
        }

        // 1 asegurar primero
        exclusivos.asegurarPrimer(getName(), p1);

        // 2  asegurar segundo con timeout
        boolean conseguidoSegundo = exclusivos.asegurarSegundoConTimeout(getName(), p2);

        if (!conseguidoSegundo) {
            // liberar primero porque no hizo pack
            exclusivos.liberar(p1);
            System.out.println(getName() + " libera " + p1 + " por fallo del segundo");
            return;
        }

        // 3 confirmar compra
        exclusivos.confirmarCompra(getName(), p1, p2);
    }
}

