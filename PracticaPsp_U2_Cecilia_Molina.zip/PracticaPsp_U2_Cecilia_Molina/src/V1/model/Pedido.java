package V1.model;

public class Pedido {

    public enum Estado {
        PENDIENTE,
        PROCESANDO,
        ENVIADO

    }

        private String id;
        private String producto;
        private Estado estado;

    public Pedido(String id, String producto, Estado estado) {
        this.id = id;
        this.producto = producto;
        this.estado = estado;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Pedido{" +
                "id=" + id +
                ", producto='" + producto + '\'' +
                ", estado=" + estado +
                '}';
    }
}
