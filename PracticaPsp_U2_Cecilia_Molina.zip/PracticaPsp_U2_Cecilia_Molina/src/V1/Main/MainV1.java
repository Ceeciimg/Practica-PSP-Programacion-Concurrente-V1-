package V1.Main;
import V1.storage.ColaPedidos;
import V1.exclusives.ProductosExclusivos;
import V1.threads.Cliente;
import V1.threads.GestorAlmacen;
import V1.threads.Transportista;

public class MainV1 {

    public static void main(String[] args) {

        System.out.println("INICIANDO SISTEMA V1 synchronized + wait/notifyAll");



        ColaPedidos cola = new ColaPedidos();
        ProductosExclusivos productos = new ProductosExclusivos();


        // CREAR CLIENTES

        Cliente cliente1 = new Cliente("Cliente-1", cola, productos);
        Cliente cliente2 = new Cliente("Cliente-2", cola, productos);
        Cliente cliente3 = new Cliente("Cliente-3", cola, productos);

        cliente1.start();
        cliente2.start();
        cliente3.start();


        // CREAR GESTORES DE ALMACÉN (HILOS CONSUMIDORES QUE PROCESAN)

        GestorAlmacen ga1 = new GestorAlmacen(cola, "Gestor-1");
        GestorAlmacen ga2 = new GestorAlmacen(cola, "Gestor-2");

        Thread gestorThread1 = new Thread(ga1);
        Thread gestorThread2 = new Thread(ga2);

        gestorThread1.start();
        gestorThread2.start();


        // CREAR TRANSPORTISTAS (HILOS QUE HACEN EL ENVÍO)

        Transportista transportista = new Transportista(cola);
        Thread tTransportista = transportista.crearHilo();
        tTransportista.start();

        try {
            Thread.sleep(30000); // 30 segundos de simulación
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("FINALIZADO SISTEMA V1");
    }
}
